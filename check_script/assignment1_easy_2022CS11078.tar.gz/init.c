// init: The initial user-level program

#include "types.h"
#include "stat.h"
#include "user.h"
#include "fcntl.h"

// MODIFIED CODE STARTS
// Macros for username and password (use the ones from the Makefile)
// #define STR_HELPER(x) #x
// #define STR(x) STR_HELPER(x)

// #define LOGIN_USERNAME STR(USERNAME)
// #define LOGIN_PASSWORD STR(PASSWORD)

void login() {
  char username[32];
  char password[32];
  int attempts = 3;

  while (attempts > 0) {
    // Prompt for username
    printf(1,"Enter username: ");
    gets(username, sizeof(username));
    username[strlen(username) - 1] = '\0'; // Remove newline

    // Check username
    if (strcmp(username, USERNAME) != 0) {
      attempts--;
      continue;
    }

    // Prompt for password
    printf(1,"Enter password: ");
    gets(password, sizeof(password));
    password[strlen(password) - 1] = '\0'; // Remove newline

    // Check password
    if (strcmp(password, PASSWORD) != 0) {
      attempts--;
      continue;
    }
    // Successful login
    printf(1,"Login successful\n");
    return;
  }

  // Out of attempts
  printf(1,"Too many failed attempts. System locked.\n");
  for (;;); // Halt the system
}

// MODIFIED CODE ENDS

char *argv[] = { "sh", 0 };

int
main(void)
{
  int pid, wpid;

  if(open("console", O_RDWR) < 0){
    mknod("console", 1, 1);
    open("console", O_RDWR);
  }
  dup(0);  // stdout
  dup(0);  // stderr

  for(;;){
    printf(1, "init: starting sh\n");
    pid = fork();
    if(pid < 0){
      printf(1, "init: fork failed\n");
      exit();
    }
    if(pid == 0){

      // MODIFIED CODE STARTS
      login();
      // MODIFIED CODE ENDS

      exec("sh", argv);
      printf(1, "init: exec sh failed\n");
      exit();
    }
    while((wpid=wait()) >= 0 && wpid != pid)
      printf(1, "zombie!\n");
  }
}
